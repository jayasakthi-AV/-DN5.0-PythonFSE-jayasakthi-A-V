#Iterative Factorial
fact=1
for i in range(1,6):
    fact*=i
print(fact)
